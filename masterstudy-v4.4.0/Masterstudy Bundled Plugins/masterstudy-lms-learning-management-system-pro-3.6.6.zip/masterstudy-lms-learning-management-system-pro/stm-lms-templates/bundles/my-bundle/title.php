<div class="stm_lms_my_bundle__title">

    <h4 class="stm_lms_my_bundle__label">
        <?php esc_html_e('Bundle name', 'masterstudy-lms-learning-management-system-pro'); ?>
    </h4>

    <input type="text"
           class="form-control"
           v-model="bundle_name"
           placeholder="<?php esc_attr_e('Enter bundle name', 'masterstudy-lms-learning-management-system-pro'); ?>" />

</div>
