<?php stm_lms_register_script('buy-button', array('jquery.cookie')); ?>

<div class="stm-lms-buy-buttons stm_lms_wizard_step_5">

	<?php STM_LMS_Templates::show_lms_template('manage_course/forms/price'); ?>

</div>