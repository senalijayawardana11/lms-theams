## 1.1.5
- **FIXED** STM Teachers blocks not displaying in Elementor

## 1.1.4
- **ADDED**: Translations of Lesson badges for Offline courses
- **FIXED**: Too large space from right side in Elementor based layouts

## 1.1.3
- Custom CSS added for auto-margin in row
- Icon box Icon background fixed
- Testimonials style 6 added

## 1.1.2
- Added controls (Icon width, Icon background color) to STM Stats Counter

## 1.1.1
- Fixed post type name in patch interface 
- Fixed Sidebar widget

## 1.1.0
- Added Template Library with two headers
- Header parts added to Elementor 

## 1.0.1  
- Icon position settings fixed
- Elementor && WPBakery conflict fixed
- Title font weight fixed

## 1.0  
- Release.